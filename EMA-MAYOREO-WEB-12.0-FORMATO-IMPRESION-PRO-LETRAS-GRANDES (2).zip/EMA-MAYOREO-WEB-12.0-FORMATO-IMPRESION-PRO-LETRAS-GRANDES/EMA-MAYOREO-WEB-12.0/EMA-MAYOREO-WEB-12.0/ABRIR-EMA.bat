@echo off
setlocal EnableExtensions

title EMA MAYOREO

set "APP_DIR=%~dp0"
set "INDEX=%APP_DIR%index.html"

if not exist "%INDEX%" (
    echo.
    echo ==========================================
    echo        EMA MAYOREO - ERROR
    echo ==========================================
    echo.
    echo No se encontro:
    echo %INDEX%
    echo.
    pause
    exit /b 1
)

pushd "%APP_DIR%" >nul 2>&1

echo.
echo ==========================================
echo          EMA MAYOREO
echo ==========================================
echo.
echo Iniciando aplicacion...
echo.

start "" "%INDEX%"

if errorlevel 1 (
    echo.
    echo No se pudo abrir EMA automaticamente.
    echo Abre manualmente:
    echo %INDEX%
    echo.
    pause
    popd >nul 2>&1
    exit /b 1
)

echo EMA MAYOREO se esta abriendo...
echo.

popd >nul 2>&1
exit /b 0