# EMA MAYOREO WEB 12.0

Reconstrucción del sistema web local de EMA con foco en estabilidad, importación de pedidos y documentos de impresión.

## Incluye
- Pedidos Actuales
- Historial y Búsqueda
- Importación XLS/XLSX/CSV y reportes ERP antiguos en HTML
- Vista previa antes de guardar
- Filtro y métricas por vendedor
- Navegación Primera/Anterior/Ir a/Siguiente/Última
- Vista previa de impresión
- Impresión media carta
- PDF media carta
- Word
- Respaldo y restauración
- Guardado local en el navegador

## No incluye
- servidor
- Node.js
- login
- CSV/Excel como botones de salida
- PDF lote
- Pago
- Configuración en la navegación principal

## Pruebas
Se valida con el reporte real PEDIDOS_REAL_EMA.xls incluido en EJEMPLOS.
