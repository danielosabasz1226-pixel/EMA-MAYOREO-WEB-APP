'use strict';
/* =========================================================
   EMA MAYOREO ELECTRÓNICO · Aplicación principal (v12.4)
========================================================= */
const STORAGE_KEY = 'ema_web_12_v3';
const DB_NAME = 'ema_mayoreo_db';
const DB_VERSION = 1;
const DB_STORE = 'app';
const COMPANY_ADDRESS = 'Ciudad de Guatemala, Guatemala';
const MAX_FILE_SIZE = 20 * 1024 * 1024; // 20 MB
const ACCEPTED_EXT = /\.(xls|xlsx|xlsm|csv|html|htm)$/i;

// Icono de impresora inline (autocontenido, no depende de sprite)
const PRINT_ICON =
  '<svg class="ico" width="16" height="16" aria-hidden="true" focusable="false" ' +
  'viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" ' +
  'stroke-linecap="round" stroke-linejoin="round">' +
  '<polyline points="6 9 6 2 18 2 18 9"/>' +
  '<path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/>' +
  '<rect x="6" y="14" width="12" height="8"/></svg>';

const state = {
  quotes: [],
  importHistory: [],
  meta: { lastFile: '', lastImportedAt: null, reportTotal: 0 }
};

let filtered = [];
let selected = 0;
let pendingImport = null;
let modalAction = null;
let sellerFilterValue = 'todo';
let sellerPreviewIndex = 0;
let toastTimer = null;
let dbPromise = null;
let focusReturn = null; // para restaurar el foco tras cerrar modales

/* =========================================================
   DOM
========================================================= */
const $ = (id) => document.getElementById(id);

/* =========================================================
   FOCO ACCESIBLE
========================================================= */
function rememberFocus() {
  focusReturn = document.activeElement;
}
function restoreFocus() {
  if (focusReturn && typeof focusReturn.focus === 'function') {
    try { focusReturn.focus(); } catch (_) { /* ignorar */ }
  }
  focusReturn = null;
}

/* =========================================================
   TEXTO
========================================================= */
function norm(value) {
  if (value === null || value === undefined) return '';
  return String(value).replace(/\u00A0/g, ' ').replace(/\s+/g, ' ').trim();
}
function cleanText(value) {
  return norm(value).replace(/^'+/, '').replace(/\uFFFD/g, '?').trim();
}
function esc(value) {
  return cleanText(value).replace(/[&<>"']/g, (char) =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char])
  );
}

/* =========================================================
   NOTIFICACIONES
========================================================= */
function toast(message, type = '') {
  const element = $('toast');
  if (!element) return;
  clearTimeout(toastTimer);
  element.textContent = message;
  element.className = `toast show${type ? ` ${type}` : ''}`;
  element.hidden = false;
  toastTimer = setTimeout(() => {
    element.className = 'toast';
    element.hidden = true;
  }, 4200);
}

/* =========================================================
   ESTADO DEL SISTEMA
========================================================= */
function setSystemStatus(text, type = 'success') {
  const textElement = $('systemStatusText');
  const dot = $('statusDot');
  if (textElement) textElement.textContent = text;
  if (dot) dot.className = `status-dot ${type}`;
}
function setImportStatus(text, success = false, error = false) {
  const status = $('importStatus');
  const overview = $('overviewStatus');
  const overviewHint = $('overviewStatusHint');
  if (status) status.textContent = text;
  if (overview) overview.textContent = error ? 'ERROR' : success ? 'OK' : 'LISTO';
  if (overviewHint) overviewHint.textContent = text;
  setSystemStatus(
    error ? 'Error de lectura' : success ? 'Archivo procesado' : text,
    error ? 'error' : success ? 'success' : 'working'
  );
}

/* =========================================================
   MONEDA / NÚMEROS
========================================================= */
function money(value) {
  const number = Number(value);
  return 'Q ' + (Number.isFinite(number) ? number : 0).toLocaleString('es-GT', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
}
function toNum(value) {
  if (typeof value === 'number' && Number.isFinite(value)) return value;
  let text = cleanText(value);
  if (!text) return 0;
  let negative = false;
  if (text.startsWith('(') && text.endsWith(')')) {
    negative = true;
    text = text.slice(1, -1);
  }
  text = text.replace(/\s/g, '').replace(/Q/gi, '').replace(/\$/g, '').replace(/%$/g, '');
  const lastComma = text.lastIndexOf(',');
  const lastDot = text.lastIndexOf('.');
  if (lastComma > -1 && lastDot > -1) {
    if (lastComma > lastDot) {
      text = text.replace(/\./g, '').replace(',', '.');
    } else {
      text = text.replace(/,/g, '');
    }
  } else if (lastComma > -1) {
    const decimals = text.length - lastComma - 1;
    if (decimals <= 3) {
      text = text.replace(/\./g, '').replace(',', '.');
    } else {
      text = text.replace(/,/g, '');
    }
  } else {
    const dotCount = (text.match(/\./g) || []).length;
    if (dotCount > 1) {
      const last = text.lastIndexOf('.');
      const integer = text.slice(0, last).replace(/\./g, '');
      const decimal = text.slice(last + 1);
      text = `${integer}.${decimal}`;
    }
  }
  text = text.replace(/[^0-9.-]/g, '');
  const number = Number(text);
  if (!Number.isFinite(number)) return 0;
  return negative ? -number : number;
}

/* =========================================================
   FECHAS
========================================================= */
function excelSerialToDate(value) {
  const serial = Number(value);
  if (!Number.isFinite(serial) || serial < 1) return null;
  const date = new Date(Date.UTC(1899, 11, 30) + serial * 86400000);
  return Number.isNaN(date.getTime()) ? null : date;
}
function parseDate(value) {
  if (value instanceof Date && !Number.isNaN(value.getTime())) return value.getTime();
  if (typeof value === 'number') {
    const date = excelSerialToDate(value);
    if (date) return date.getTime();
  }
  const text = cleanText(value);
  if (!text) return null;
  const match = text.match(/(\d{1,4})[\/.\-](\d{1,2})[\/.\-](\d{1,4})/);
  if (match) {
    const first = Number(match[1]);
    const second = Number(match[2]);
    const third = Number(match[3]);
    let year, month, day;
    if (first >= 1900) {
      year = first; month = second; day = third;
    } else if (third >= 1900) {
      year = third; month = second; day = first;
      if (month > 12 && day <= 12) [month, day] = [day, month];
    } else {
      year = third < 100 ? third + 2000 : third;
      month = second; day = first;
    }
    const date = new Date(year, month - 1, day);
    if (date.getFullYear() === year && date.getMonth() === month - 1 && date.getDate() === day) {
      return date.getTime();
    }
  }
  const parsed = Date.parse(text);
  return Number.isFinite(parsed) ? parsed : null;
}
function dateText(value) {
  const timestamp = parseDate(value);
  if (!timestamp) return cleanText(value);
  const date = new Date(timestamp);
  return [
    String(date.getDate()).padStart(2, '0'),
    String(date.getMonth() + 1).padStart(2, '0'),
    date.getFullYear()
  ].join('/');
}
function startOfTodayTs() {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  return d.getTime();
}

/* =========================================================
   CÓDIGOS / NOMBRES
========================================================= */
function splitParty(value) {
  const source = cleanText(value);
  if (!source) return { code: '', name: '' };
  let code = '';
  let name = source;
  const pipeIndex = source.indexOf('|');
  if (pipeIndex >= 0) {
    code = cleanText(source.slice(0, pipeIndex));
    name = cleanText(source.slice(pipeIndex + 1));
  }
  const equalMatch = name.match(/^(.+?)\s*=\s*([A-Z0-9._-]+)$/i);
  if (equalMatch) {
    name = cleanText(equalMatch[1]);
    if (!code) code = cleanText(equalMatch[2]);
  }
  return { code, name: name || source };
}

/* =========================================================
   ALIASES DE COLUMNAS
========================================================= */
const ALIASES = {
  pedido: ['PEDIDO','N PEDIDO','NO PEDIDO','NO. PEDIDO','NUM PEDIDO','NUMERO PEDIDO','NUMERO DE PEDIDO','COTIZACION','N COTIZACION','NO COTIZACION','NO. COTIZACION','NUM COTIZACION','ORDEN','ORDEN DE COMPRA'],
  cliente: ['CLIENTE','NOMBRE CLIENTE','RAZON SOCIAL','RAZON SOCIAL CLIENTE','CLIENTE NOMBRE','NOMBRE'],
  direccion: ['DIRECCION','DIRECCION CLIENTE','DIRECCION DE CLIENTE','DIRECCION ENTREGA','DIRECCION DE ENTREGA','DIRECCION FISCAL','DOMICILIO','DOMICILIO CLIENTE','UBICACION','DIRECCION ENVIO','DIRECCION DE ENVIO'],
  fecha: ['FECHA','FECHA PEDIDO','FECHA COTIZACION','FECHA DE COTIZACION','FECHA EMISION','FECHA DE EMISION','FECHA DOCUMENTO'],
  vendedor: ['VENDEDOR','VENDEDOR COMERCIAL','ASESOR','ASESOR COMERCIAL','EJECUTIVO','EJECUTIVO DE VENTAS','VENDEDOR PEDIDO'],
  desc: ['CONCEPTO DETALLE','CONCEPTO','DESCRIPCION','DESCRIPCION DETALLE','PRODUCTO','DETALLE','ITEM','ARTICULO','ARTICULO DESCRIPCION','NOMBRE PRODUCTO'],
  cantidad: ['CANTIDAD PEDIDO','CANTIDAD DETALLE','CANTIDAD','CANT','CANT.','UNIDADES','QTY'],
  precio: ['PRECIO VENTA','PRECIO UNITARIO','PRECIO UNIT','PRECIO U','P UNITARIO','P. UNITARIO','PRECIO','UNIT PRICE'],
  total: ['TOTAL VENTA','TOTAL VENTA REAL','TOTAL LINEA','TOTAL DETALLE','IMPORTE LINEA','IMPORTE','SUBTOTAL','TOTAL']
};
const WEIGHTS = { pedido: 10, cliente: 10, direccion: 8, fecha: 6, vendedor: 8, desc: 9, cantidad: 6, precio: 7, total: 7 };

function normalizeKey(value) {
  return cleanText(value).toUpperCase().normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '').replace(/[^A-Z0-9]+/g, ' ').trim();
}
function headerScore(cell, field) {
  const key = normalizeKey(cell);
  if (!key) return 0;
  const aliases = ALIASES[field] || [];
  let score = 0;
  aliases.forEach((alias, index) => {
    const normalized = normalizeKey(alias);
    if (key === normalized) {
      score = Math.max(score, 1000 + aliases.length - index);
      return;
    }
    if (key.startsWith(`${normalized} `) || key.endsWith(` ${normalized}`)) {
      score = Math.max(score, 700 + aliases.length - index);
      return;
    }
    if (key.includes(normalized)) {
      score = Math.max(score, 400 + aliases.length - index);
    }
  });
  return score;
}
function findCol(header, field) {
  let index = -1;
  let best = 0;
  header.forEach((cell, position) => {
    const score = headerScore(cell, field);
    if (score > best) { best = score; index = position; }
  });
  return index;
}
function scoreHeaderRow(row) {
  let score = 0;
  let hits = 0;
  Object.keys(ALIASES).forEach((field) => {
    if (findCol(row, field) >= 0) { hits += 1; score += WEIGHTS[field]; }
  });
  if (findCol(row, 'pedido') >= 0 && findCol(row, 'cliente') >= 0) score += 18;
  if (findCol(row, 'desc') >= 0 && findCol(row, 'cantidad') >= 0) score += 12;
  if (findCol(row, 'precio') >= 0 && findCol(row, 'total') >= 0) score += 10;
  return { score, hits };
}
function detectHeader(rows) {
  let best = { index: -1, score: -1, hits: 0 };
  const limit = Math.min(rows.length, 300);
  for (let index = 0; index < limit; index++) {
    const result = scoreHeaderRow(rows[index] || []);
    if (result.score > best.score) best = { index, ...result };
  }
  return best.hits >= 3 ? best.index : -1;
}

/* =========================================================
   ARCHIVOS / CODIFICACIÓN
========================================================= */
async function readArrayBuffer(file) {
  if (typeof file.arrayBuffer === 'function') return file.arrayBuffer();
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(reader.error || new Error('No se pudo leer el archivo.'));
    reader.readAsArrayBuffer(file);
  });
}
function decodeText(buffer, encoding = 'windows-1252') {
  if (typeof TextDecoder === 'undefined') {
    const bytes = new Uint8Array(buffer);
    let output = '';
    for (let i = 0; i < bytes.length; i++) output += String.fromCharCode(bytes[i]);
    return output;
  }
  try {
    return new TextDecoder(encoding).decode(new Uint8Array(buffer));
  } catch (_) {
    return new TextDecoder().decode(new Uint8Array(buffer));
  }
}
function looksLikeHtml(buffer) {
  const text = decodeText(buffer, 'windows-1252').slice(0, 8000).replace(/^\uFEFF/, '').trim();
  return /^<!doctype\s+html/i.test(text) || /^<html\b/i.test(text) || /<table[\s>]/i.test(text);
}

/* =========================================================
   HTML / REPORTES ANTIGUOS
========================================================= */
function directTableRows(table) {
  const rows = [];
  table.querySelectorAll('tr').forEach((tr) => {
    const cells = tr.querySelectorAll(':scope > th, :scope > td');
    if (!cells.length) return;
    rows.push([...cells].map((cell) => cleanText(cell.textContent)));
  });
  return rows;
}
function parseHtmlTables(text) {
  const doc = new DOMParser().parseFromString(text, 'text/html');
  let tables = [...doc.querySelectorAll('table')];
  const preferred = doc.querySelector('#dgdreporte');
  if (preferred) {
    tables = [preferred, ...tables.filter((t) => t !== preferred)];
  } else {
    tables.sort((a, b) => directTableRows(b).length - directTableRows(a).length);
  }
  let best = { rows: [], headerIndex: -1, score: -1 };
  for (const table of tables) {
    const rows = directTableRows(table);
    for (let i = 0; i < Math.min(rows.length, 300); i++) {
      const result = scoreHeaderRow(rows[i]);
      if (result.score > best.score) best = { rows, headerIndex: i, score: result.score };
    }
  }
  return best;
}

/* =========================================================
   SHEETJS
========================================================= */
function sheetRows(sheet) {
  return XLSX.utils.sheet_to_json(sheet, { header: 1, defval: '', raw: false, blankrows: false });
}
function chooseWorkbookRows(workbook) {
  let best = { rows: [], name: '', score: -1, headerIndex: -1 };
  for (const name of workbook.SheetNames) {
    const rows = sheetRows(workbook.Sheets[name]);
    if (!rows.length) continue;
    for (let i = 0; i < Math.min(rows.length, 300); i++) {
      const row = rows[i] || [];
      const result = scoreHeaderRow(row);
      let score = result.score;
      if (rows.length > 20) score += 2;
      if (findCol(row, 'pedido') >= 0) score += 5;
      if (findCol(row, 'desc') >= 0) score += 5;
      if (score > best.score) best = { rows, name, score, headerIndex: i };
    }
  }
  if (!best.rows.length) throw new Error('El archivo no contiene datos utilizables.');
  return best;
}
function parseExcel(buffer) {
  if (typeof XLSX === 'undefined') throw new Error('El lector Excel no se cargó. Revisa lib/xlsx.full.min.js.');
  const workbook = XLSX.read(buffer, { type: 'array', cellDates: true, raw: false, codepage: 1252, dense: true });
  return chooseWorkbookRows(workbook);
}
function parseCsv(buffer) {
  if (typeof XLSX === 'undefined') throw new Error('El lector CSV no se cargó.');
  let text = decodeText(buffer, 'utf-8');
  if (text.includes('�')) text = decodeText(buffer, 'windows-1252');
  const workbook = XLSX.read(text, { type: 'string', raw: false, codepage: 1252 });
  return chooseWorkbookRows(workbook);
}

/* =========================================================
   FILAS / PEDIDOS
========================================================= */
function isSummaryRow(row) {
  const text = normalizeKey((row || []).join(' '));
  return /\bTOTAL POR CLIENTE\b/.test(text) || /\bTOTAL GENERAL\b/.test(text) || /^\s*TOTALES?\b/.test(text);
}
function isGlobalTotalRow(row) {
  const text = normalizeKey((row || []).join(' '));
  return /\bTOTAL GENERAL\b/.test(text) || /^\s*TOTALES?\b/.test(text);
}
function parseRows(file, rows, source = {}) {
  const headerIndex = Number.isInteger(source.headerIndex) ? source.headerIndex : detectHeader(rows);
  if (headerIndex < 0) throw new Error('No encontré una fila de encabezados reconocible.');
  const header = (rows[headerIndex] || []).map(cleanText);
  const columns = {};
  for (const field of Object.keys(ALIASES)) columns[field] = findCol(header, field);
  if (columns.pedido < 0) throw new Error('No encontré la columna PEDIDO o N. DE PEDIDO.');
  if (columns.cliente < 0) throw new Error('No encontré la columna CLIENTE o RAZÓN SOCIAL.');
  if (columns.desc < 0) throw new Error('No encontré la columna de descripción del producto.');

  const groups = new Map();
  let lastOrder = '';
  let reportTotal = 0;

  for (let r = headerIndex + 1; r < rows.length; r++) {
    const row = rows[r] || [];
    if (!row.some((v) => cleanText(v) !== '')) continue;

    if (isSummaryRow(row)) {
      if (isGlobalTotalRow(row)) {
        const total = columns.total >= 0 ? toNum(row[columns.total]) : 0;
        if (total > 0) reportTotal = total;
        continue;
      }
    }

    let number = columns.pedido >= 0 ? cleanText(row[columns.pedido]) : '';
    if (!number) number = lastOrder;
    if (!number) continue;
    lastOrder = number;

    if (!groups.has(number)) {
      groups.set(number, {
        numero: number, cliente: '', direccion: '', fecha: '', vendedor: '',
        items: [], summaryTotal: 0, archivo: file.name, source: source.format || 'archivo'
      });
    }
    const group = groups.get(number);

    if (isSummaryRow(row)) {
      const summaryText = normalizeKey(row.join(' '));
      if (/\bTOTAL POR CLIENTE\b/.test(summaryText)) {
        const summaryTotal = columns.total >= 0 ? toNum(row[columns.total]) : 0;
        if (summaryTotal > 0) group.summaryTotal = summaryTotal;
      }
      continue;
    }

    if (columns.cliente >= 0) {
      const v = cleanText(row[columns.cliente]);
      if (v) group.cliente = v;
    }
    if (columns.direccion >= 0) {
      const v = cleanText(row[columns.direccion]);
      if (v) group.direccion = v;
    }
    if (columns.fecha >= 0) {
      const v = cleanText(row[columns.fecha]);
      if (v) group.fecha = v;
    }
    if (columns.vendedor >= 0) {
      const v = cleanText(row[columns.vendedor]);
      if (v) group.vendedor = v;
    }

    const description = columns.desc >= 0 ? cleanText(row[columns.desc]) : '';
    if (!description) continue;
    if (/^TOTAL\b/i.test(description) || /^TOTALES?\b/i.test(description)) continue;

    const quantity = columns.cantidad >= 0 ? toNum(row[columns.cantidad]) : 0;
    let price = columns.precio >= 0 ? toNum(row[columns.precio]) : 0;
    let lineTotal = columns.total >= 0 ? toNum(row[columns.total]) : 0;
    if (!lineTotal && quantity && price) lineTotal = quantity * price;
    if (!price && quantity && lineTotal) price = lineTotal / quantity;

    const item = splitParty(description);
    group.items.push({
      codigo: item.code, descripcion: item.name,
      cantidad: quantity, precio: price, total: lineTotal
    });
  }

  const quotes = [];
  for (const group of groups.values()) {
    if (!group.items.length) continue;
    const customer = splitParty(group.cliente);
    const seller = splitParty(group.vendedor);
    const calculatedTotal = group.items.reduce((sum, item) => sum + Number(item.total || 0), 0);
    const amount = group.summaryTotal > 0 ? group.summaryTotal : calculatedTotal;
    quotes.push({
      id: `q_${group.numero}`,
      numero: group.numero,
      clientCode: customer.code,
      cliente: customer.name,
      direccion: group.direccion,
      fecha: dateText(group.fecha),
      fechaTs: parseDate(group.fecha),
      vendedorCode: seller.code,
      vendedor: seller.name,
      archivo: group.archivo,
      items: group.items,
      monto: amount,
      createdAt: Date.now(),
      source: group.source
    });
  }
  if (!quotes.length) throw new Error('El archivo fue leído, pero no encontré pedidos con productos.');
  return { quotes, reportTotal };
}

/* =========================================================
   PARSE FILE
========================================================= */
async function parseFile(file) {
  if (!file) throw new Error('No se recibió ningún archivo.');
  const name = cleanText(file.name).toLowerCase();
  if (!ACCEPTED_EXT.test(name)) throw new Error('Formato no compatible. Usa XLS, XLSX, XLSM, CSV, HTML o HTM.');
  if (file.size > MAX_FILE_SIZE) throw new Error('El archivo supera los 20 MB recomendados.');

  const buffer = await readArrayBuffer(file);

  if (/\.(html|htm)$/i.test(name) || looksLikeHtml(buffer)) {
    const text = decodeText(buffer, 'windows-1252');
    const parsed = parseHtmlTables(text);
    if (!parsed.rows.length) throw new Error('No encontré una tabla de pedidos dentro del reporte.');
    return parseRows(file, parsed.rows, { format: 'html-report', headerIndex: parsed.headerIndex });
  }
  if (/\.csv$/i.test(name)) {
    const parsed = parseCsv(buffer);
    return parseRows(file, parsed.rows, { format: 'csv', headerIndex: parsed.headerIndex });
  }
  const parsed = parseExcel(buffer);
  return parseRows(file, parsed.rows, { format: 'excel', sheet: parsed.name, headerIndex: parsed.headerIndex });
}

/* =========================================================
   NORMALIZAR QUOTE
========================================================= */
function normalizeQuote(quote) {
  return {
    ...quote,
    numero: cleanText(quote.numero),
    cliente: cleanText(quote.cliente),
    direccion: cleanText(quote.direccion),
    fecha: cleanText(quote.fecha),
    vendedor: cleanText(quote.vendedor),
    items: Array.isArray(quote.items)
      ? quote.items.map((item) => ({
          codigo: cleanText(item.codigo),
          descripcion: cleanText(item.descripcion),
          cantidad: Number(item.cantidad) || 0,
          precio: Number(item.precio) || 0,
          total: Number(item.total) || 0
        }))
      : [],
    monto: Number(quote.monto) || 0
  };
}

/* =========================================================
   INDEXEDDB
========================================================= */
function openDatabase() {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise((resolve) => {
    if (!('indexedDB' in window)) { resolve(null); return; }
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(DB_STORE)) db.createObjectStore(DB_STORE);
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => resolve(null);
  });
  return dbPromise;
}
async function saveIndexedDB() {
  const db = await openDatabase();
  if (!db) return false;
  return new Promise((resolve) => {
    try {
      const tx = db.transaction(DB_STORE, 'readwrite');
      tx.objectStore(DB_STORE).put(JSON.parse(JSON.stringify(state)), 'state');
      tx.oncomplete = () => resolve(true);
      tx.onerror = () => resolve(false);
      tx.onabort = () => resolve(false);
    } catch (_) { resolve(false); }
  });
}
async function loadIndexedDB() {
  const db = await openDatabase();
  if (!db) return null;
  return new Promise((resolve) => {
    try {
      const tx = db.transaction(DB_STORE, 'readonly');
      const request = tx.objectStore(DB_STORE).get('state');
      request.onsuccess = () => resolve(request.result || null);
      request.onerror = () => resolve(null);
    } catch (_) { resolve(null); }
  });
}

/* =========================================================
   STORAGE
========================================================= */
function saveState() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    setSystemStatus('Guardado local', 'success');
  } catch (error) {
    console.warn('localStorage no disponible:', error);
    setSystemStatus('Sesión activa', 'working');
  }
  saveIndexedDB().catch((error) => console.warn('IndexedDB:', error));
}
function applyState(value) {
  if (!value) return false;
  if (Array.isArray(value.quotes)) state.quotes = value.quotes.map(normalizeQuote);
  if (Array.isArray(value.importHistory)) {
    state.importHistory = value.importHistory.map((entry) => ({
      id: cleanText(entry.id) || `imp_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
      fileName: cleanText(entry.fileName),
      importedAt: Number(entry.importedAt) || Date.now(),
      mode: entry.mode === 'append' ? 'append' : 'replace',
      count: Number(entry.count) || 0,
      total: Number(entry.total) || 0,
      preview: Array.isArray(entry.preview) ? entry.preview.map(normalizeQuote) : []
    }));
  } else if (!Array.isArray(state.importHistory)) {
    state.importHistory = [];
  }
  if (value.meta && typeof value.meta === 'object') state.meta = { ...state.meta, ...value.meta };
  return true;
}
function loadState() {
  const keys = [STORAGE_KEY, 'ema_web_12_v2', 'ema_web_12_v1', 'ema_web_robust_v1'];
  for (const key of keys) {
    try {
      const raw = localStorage.getItem(key);
      if (!raw) continue;
      const parsed = JSON.parse(raw);
      if (applyState(parsed)) break;
    } catch (error) {
      console.warn(`No se pudo leer ${key}`, error);
    }
  }
  loadIndexedDB().then((indexedState) => {
    if (!indexedState) return;
    const indexedCount = Array.isArray(indexedState.quotes) ? indexedState.quotes.length : 0;
    if (indexedCount > state.quotes.length) {
      applyState(indexedState);
      populateSellers();
      renderHistory();
      renderImportHistory();
      renderQuote();
    }
  });
}

/* =========================================================
   IMPORTACIÓN / HISTORIAL DE CARGAS
========================================================= */
function pushImportHistory(quotes, reportTotal, fileName, mode) {
  const normalized = quotes.map(normalizeQuote);
  const total = normalized.reduce((sum, q) => sum + Number(q.monto || 0), 0);
  state.importHistory = Array.isArray(state.importHistory) ? state.importHistory : [];
  state.importHistory.unshift({
    id: `imp_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
    fileName: fileName || normalized[0]?.archivo || 'Archivo sin nombre',
    importedAt: Date.now(),
    mode: mode === 'append' ? 'append' : 'replace',
    count: normalized.length,
    total: Number(reportTotal) > 0 ? Number(reportTotal) : total,
    // Se conserva una muestra suficiente para consultar la carga sin inflar el almacenamiento.
    preview: normalized.slice(0, 200)
  });
  state.importHistory = state.importHistory.slice(0, 20);
}

function finalizeImported(quotes, reportTotal, fileName, mode) {
  const normalized = quotes.map((quote) => ({
    ...normalizeQuote(quote),
    id: normalizeQuote(quote).id || `q_${cleanText(quote.numero) || Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
    createdAt: normalizeQuote(quote).createdAt || Date.now()
  }));

  if (mode === 'append') {
    const map = new Map();
    state.quotes.forEach((quote) => {
      const q = normalizeQuote(quote);
      if (q.numero) map.set(q.numero, q);
    });
    normalized.forEach((quote) => {
      if (!quote.numero) return;
      const existing = map.get(quote.numero);
      map.set(quote.numero, {
        ...(existing || {}),
        ...quote,
        id: existing?.id || quote.id,
        createdAt: existing?.createdAt || quote.createdAt
      });
    });
    state.quotes = [...map.values()];
  } else {
    state.quotes = normalized.filter((q) => q.numero);
  }

  state.meta.lastFile = fileName || normalized[0]?.archivo || '';
  state.meta.lastImportedAt = Date.now();
  state.meta.reportTotal = Number(reportTotal) || normalized.reduce((sum, q) => sum + Number(q.monto || 0), 0);
  pushImportHistory(normalized, reportTotal, fileName, mode);
  saveState();
  selected = 0;
  sellerFilterValue = 'todo';
  populateSellers();
  renderHistory();
  renderImportHistory();
  renderQuote();
}

function replaceImported(quotes, reportTotal, fileName) {
  finalizeImported(quotes, reportTotal, fileName, 'replace');
}

function mergeImported(quotes, reportTotal, fileName) {
  finalizeImported(quotes, reportTotal, fileName, 'append');
}

function renderImportHistory() {
  const entries = Array.isArray(state.importHistory) ? state.importHistory : [];
  const body = $('importHistoryBody');
  const empty = $('importHistoryEmpty');
  const count = $('importHistoryCount');
  if (!body || !empty || !count) return;
  count.textContent = `${entries.length} ${entries.length === 1 ? 'carga' : 'cargas'}`;
  empty.hidden = entries.length > 0;
  body.innerHTML = entries.map((entry) => `
    <tr>
      <td>${esc(new Date(entry.importedAt).toLocaleString('es-GT'))}</td>
      <td><b>${esc(entry.fileName || '—')}</b></td>
      <td><span class="import-mode ${entry.mode === 'append' ? 'append' : 'replace'}">${entry.mode === 'append' ? 'Agregado' : 'Reemplazado'}</span></td>
      <td>${entry.count.toLocaleString('es-GT')}</td>
      <td>${esc(money(entry.total))}</td>
      <td><button type="button" class="btn small secondary" data-import-act="view" data-id="${esc(entry.id)}">Ver</button></td>
    </tr>
  `).join('');
}

function openImportHistoryPreview(id) {
  const entry = state.importHistory.find((item) => item.id === id);
  if (!entry) return;
  $('importHistoryPreviewTitle').textContent = entry.fileName || 'Detalle de la carga';
  $('importHistoryPreviewInfo').innerHTML = [
    ['Fecha', new Date(entry.importedAt).toLocaleString('es-GT')],
    ['Modo', entry.mode === 'append' ? 'Agregado a la base' : 'Reemplazó la base'],
    ['Pedidos', entry.count],
    ['Total', money(entry.total)],
    ['Muestra', `Primeros ${Math.min(entry.preview.length, 200)} pedidos`]
  ].map(([label, value]) => `<div class="preview-chip"><b>${esc(label)}</b><span>${esc(value)}</span></div>`).join('');
  $('importHistoryPreviewTable').innerHTML = `
    <table>
      <thead><tr><th>N. pedido</th><th>Cliente</th><th>Dirección</th><th>Vendedor</th><th>Total</th></tr></thead>
      <tbody>
        ${entry.preview.map((q) => `<tr>
          <td>${esc(q.numero)}</td><td>${esc(q.cliente || '—')}</td><td>${esc(q.direccion || '—')}</td><td>${esc(q.vendedor || '—')}</td><td>${esc(money(q.monto))}</td>
        </tr>`).join('')}
      </tbody>
    </table>`;
  rememberFocus();
  $('importHistoryPreviewBg').hidden = false;
  $('importHistoryPreviewBg').classList.add('open');
  $('importHistoryPreviewClose').focus();
}
function closeImportHistoryPreview() {
  $('importHistoryPreviewBg').classList.remove('open');
  $('importHistoryPreviewBg').hidden = true;
  restoreFocus();
}

/* =========================================================
   VISTA PREVIA IMPORTACIÓN
========================================================= */
function renderPreview(quotes, reportTotal) {
  const detectedTotal = quotes.reduce((sum, q) => sum + Number(q.monto || 0), 0);
  const lineCount = quotes.reduce((sum, q) => sum + (Array.isArray(q.items) ? q.items.length : 0), 0);
  const first = quotes[0];
  const values = [
    ['Pedidos', quotes.length],
    ['Líneas', lineCount],
    ['Primer cliente', first?.cliente || '—'],
    ['Dirección', first?.direccion || '—'],
    ['Venta detectada', money(reportTotal > 0 ? reportTotal : detectedTotal)]
  ];
  $('previewInfo').innerHTML = values.map(([label, value]) => `
    <div class="preview-chip"><b>${esc(label)}</b><span>${esc(value)}</span></div>
  `).join('');
  $('previewTable').innerHTML = `
    <table>
      <thead><tr>
        <th>N. pedido</th><th>Cliente</th><th>Dirección</th>
        <th>Vendedor</th><th>Líneas</th><th>Total</th>
      </tr></thead>
      <tbody>
        ${quotes.slice(0, 120).map((q) => `
          <tr>
            <td>${esc(q.numero)}</td>
            <td>${esc(q.cliente || '—')}</td>
            <td>${esc(q.direccion || '—')}</td>
            <td>${esc(q.vendedor || '—')}</td>
            <td>${q.items.length}</td>
            <td>${esc(money(q.monto))}</td>
          </tr>`).join('')}
      </tbody>
    </table>`;
  $('previewNote').textContent = quotes.length > 120
    ? `Se detectaron ${quotes.length} pedidos. Se muestran los primeros 120 en esta revisión.`
    : 'Los pedidos no se guardan hasta confirmar.';
}
function closeImportPreview() {
  const bg = $('previewBg');
  if (bg) {
    bg.classList.remove('open');
    bg.hidden = true;
  }
  pendingImport = null;
  restoreFocus();
}

/* =========================================================
   FILTROS
========================================================= */
function applyFilters() {
  const search = cleanText($('search')?.value).toLowerCase();
  const sort = $('sort')?.value || 'fecha_desc';
  const date = $('dateFilter')?.value || 'todo';
  const seller = sellerFilterValue || 'todo';
  const now = Date.now();
  const day = 86400000;
  const todayTs = startOfTodayTs();

  filtered = state.quotes.filter((quote) => {
    if (seller !== 'todo' && quote.vendedor !== seller) return false;
    if (date !== 'todo' && quote.fechaTs) {
      if (date === 'hoy') {
        if (quote.fechaTs < todayTs) return false;
      } else {
        const age = now - quote.fechaTs;
        const windowDays = date === 'semana' ? 7 : 30;
        if (age < 0 || age > windowDays * day) return false;
      }
    }
    if (search) {
      const haystack = [quote.numero, quote.cliente, quote.clientCode, quote.direccion, quote.vendedor, quote.archivo]
        .join(' ').toLowerCase();
      if (!haystack.includes(search)) return false;
    }
    return true;
  });

  filtered.sort((a, b) => {
    switch (sort) {
      case 'fecha_asc': return (a.fechaTs || 0) - (b.fechaTs || 0);
      case 'num_asc': return String(a.numero).localeCompare(String(b.numero), 'es');
      case 'num_desc': return String(b.numero).localeCompare(String(a.numero), 'es');
      case 'cli_asc': return String(a.cliente).localeCompare(String(b.cliente), 'es');
      case 'monto_desc': return Number(b.monto || 0) - Number(a.monto || 0);
      case 'monto_asc': return Number(a.monto || 0) - Number(b.monto || 0);
      default: return (b.fechaTs || 0) - (a.fechaTs || 0);
    }
  });

  if (selected >= filtered.length) selected = Math.max(0, filtered.length - 1);
}

/* =========================================================
   VENDEDORES
========================================================= */
function populateSellers() {
  const sellers = [...new Set(
    state.quotes.map((q) => cleanText(q.vendedor)).filter(Boolean)
  )].sort((a, b) => a.localeCompare(b, 'es'));

  const options = `
    <option value="todo">Todos</option>
    ${sellers.map((s) => `<option value="${esc(s)}">${esc(s)}</option>`).join('')}
  `;
  ['sellerFilter', 'quoteSellerFilter'].forEach((id) => {
    const select = $(id);
    if (!select) return;
    select.innerHTML = options;
    select.value = sellers.includes(sellerFilterValue) ? sellerFilterValue : 'todo';
  });
  if (!sellers.includes(sellerFilterValue)) sellerFilterValue = 'todo';
}
function getSellerStats() {
  const seller = sellerFilterValue || 'todo';
  const list = seller === 'todo'
    ? state.quotes
    : state.quotes.filter((q) => q.vendedor === seller);
  const total = list.reduce((sum, q) => sum + Number(q.monto || 0), 0);
  const average = list.length ? total / list.length : 0;
  return { seller, list, total, average, current: filtered[selected] || null };
}
function renderSellerDashboard() {
  const stats = getSellerStats();
  const title = $('seller-dashboard-heading');
  const subtitle = $('sellerSubtitle');
  if (title) title.textContent = stats.seller === 'todo' ? 'Todos los vendedores' : stats.seller;
  if (subtitle) {
    subtitle.textContent = stats.seller === 'todo'
      ? 'Resumen general de todos los pedidos guardados.'
      : `${stats.list.length} pedido(s) atribuido(s) a este vendedor.`;
  }
  $('sellerOrders').textContent = stats.list.length.toLocaleString('es-GT');
  $('sellerSales').textContent = money(stats.total);
  $('sellerAverage').textContent = money(stats.average);
  $('sellerCurrent').textContent = money(stats.current?.monto || 0);
  // innerHTML para conservar el icono (textContent lo borraría)
  $('btnPrintAll').innerHTML = stats.seller === 'todo'
    ? `${PRINT_ICON} Imprimir todos`
    : `${PRINT_ICON} Imprimir vendedor`;
}

/* =========================================================
   FACTURA
========================================================= */
function formatItemRows(quote) {
  return quote.items.map((item) => `
    <tr>
      <td>
        ${esc(item.descripcion || '—')}
        ${item.codigo ? `<span class="cod">Cód. ${esc(item.codigo)}</span>` : ''}
      </td>
      <td class="num">${Number(item.cantidad || 0).toLocaleString('es-GT', { maximumFractionDigits: 2 })}</td>
      <td class="num">${money(item.precio)}</td>
      <td class="num">${money(item.total)}</td>
    </tr>`).join('');
}
function invoice(quote) {
  if (!quote) return '';
  return `
    <article class="invoice">
      <header class="inv-head">
        <div class="company">MAYOREO ELECTRÓNICO, S.A.</div>
        <div class="address">${esc(COMPANY_ADDRESS)}</div>
        <div class="title">PEDIDO</div>
      </header>
      <table class="meta"><tbody>
        <tr>
          <th>N. DE COTIZACIÓN:</th><td><b>${esc(quote.numero)}</b></td>
          <th>FECHA:</th><td>${esc(quote.fecha || '—')}</td>
        </tr>
        <tr><th>CLIENTE:</th><td colspan="3">${esc(quote.cliente || '—')}</td></tr>
        <tr><th>DIRECCIÓN:</th><td colspan="3">${esc(quote.direccion || '—')}</td></tr>
        <tr><th>VENDEDOR:</th><td colspan="3">${esc(quote.vendedor || '—')}</td></tr>
      </tbody></table>
      <table class="items">
        <thead><tr>
          <th>DESCRIPCIÓN</th>
          <th class="num">CANTIDAD</th>
          <th class="num">PRECIO UNITARIO</th>
          <th class="num">TOTAL</th>
        </tr></thead>
        <tbody>${formatItemRows(quote)}</tbody>
      </table>
      <table class="total"><tbody>
        <tr>
          <td class="label">TOTAL DEL PEDIDO</td>
          <td class="value">${money(quote.monto)}</td>
        </tr>
      </tbody></table>
      <div class="inv-footer">Gracias por su preferencia.</div>
      <div class="inv-cond">Precios en Quetzales. Documento generado por Sistema EMA.</div>
    </article>`;
}

/* =========================================================
   RENDER PEDIDOS
========================================================= */
function currentQuote() {
  applyFilters();
  return filtered[selected] || null;
}
function renderQuote() {
  applyFilters();
  renderSellerDashboard();
  const quote = filtered[selected] || null;

  $('position').textContent = quote ? `${selected + 1} de ${filtered.length}` : '0 de 0';
  $('positionHint').textContent = quote
    ? `${quote.cliente || 'Cliente sin nombre'} · ${money(quote.monto)}`
    : 'Importa un archivo para comenzar';
  $('emptyState').hidden = Boolean(quote);
  $('invoiceWrap').innerHTML = quote ? invoice(quote) : '';
  $('stageBadge').textContent = quote ? `Pedido ${quote.numero}` : 'Sin selección';

  const jump = $('quoteJump');
  jump.innerHTML = filtered.length
    ? filtered.map((item, index) => `
        <option value="${index}">${esc(item.numero)} · ${esc(item.cliente || 'Sin cliente')}</option>
      `).join('')
    : `<option value="">Sin pedidos</option>`;
  if (quote) jump.value = String(selected);

  $('btnFirst').disabled = !quote || selected <= 0;
  $('btnPrev').disabled = !quote || selected <= 0;
  $('btnNext').disabled = !quote || selected >= filtered.length - 1;
  $('btnLast').disabled = !quote || selected >= filtered.length - 1;
}

/* =========================================================
   HISTORIAL
========================================================= */
function renderHistory() {
  populateSellers();
  applyFilters();
  renderSellerDashboard();

  const total = state.quotes.reduce((sum, q) => sum + Number(q.monto || 0), 0);
  const sellers = new Set(state.quotes.map((q) => cleanText(q.vendedor)).filter(Boolean));

  $('counter').textContent = `Mostrando ${filtered.length} de ${state.quotes.length} pedidos`;
  $('statCount').textContent = `${state.quotes.length} pedidos`;
  $('statMonto').textContent = money(total);
  $('overviewCount').textContent = state.quotes.length.toLocaleString('es-GT');
  $('overviewMonto').textContent = money(total);
  $('overviewVendedores').textContent = sellers.size.toLocaleString('es-GT');
  $('historyEmpty').hidden = filtered.length > 0;

  $('historyBody').innerHTML = filtered.map((quote) => `
    <tr>
      <td><b>${esc(quote.numero)}</b></td>
      <td>${esc(quote.fecha || '—')}</td>
      <td>${esc(quote.cliente || '—')}</td>
      <td>${esc(quote.direccion || '—')}</td>
      <td>${esc(quote.vendedor || '—')}</td>
      <td>${esc(money(quote.monto))}</td>
      <td>
        <button type="button" class="btn small secondary" data-act="view" data-id="${esc(quote.id)}">Ver</button>
        <button type="button" class="btn small danger" data-act="del" data-id="${esc(quote.id)}">Eliminar</button>
      </td>
    </tr>`).join('');

  $('lastFile').textContent = state.meta.lastFile || 'Ninguno';
  $('lastFileMeta').textContent = state.meta.lastImportedAt
    ? `Importado ${new Date(state.meta.lastImportedAt).toLocaleString('es-GT')}`
    : 'Importa un pedido para verlo aquí.';
}

/* =========================================================
   TABS / NAVEGACIÓN
========================================================= */
function setTab(tab) {
  document.querySelectorAll('.tab').forEach((button) => {
    const active = button.dataset.tab === tab;
    button.classList.toggle('active', active);
    button.setAttribute('aria-selected', String(active));
  });
  document.querySelectorAll('.tab-panel').forEach((panel) => {
    panel.hidden = panel.id !== `tab-${tab}`;
  });
}
function goToQuote(index) {
  applyFilters();
  if (!filtered.length) { selected = 0; renderQuote(); return; }
  selected = Math.max(0, Math.min(filtered.length - 1, index));
  renderQuote();
}

/* =========================================================
   IMPORTACIÓN
========================================================= */
async function handleFile(file) {
  if (!file) return;
  const name = String(file.name || '').toLowerCase();
  if (!ACCEPTED_EXT.test(name)) {
    setImportStatus('Formato no compatible', false, true);
    toast('Usa XLS, XLSX, XLSM, CSV, HTML o HTM.', 'err');
    return;
  }
  if (file.size > MAX_FILE_SIZE) {
    setImportStatus('Archivo demasiado grande', false, true);
    toast('El archivo supera los 20 MB recomendados.', 'err');
    return;
  }
  try {
    setImportStatus(`Leyendo ${file.name}...`);
    toast(`Leyendo ${file.name}...`);
    const result = await parseFile(file);
    pendingImport = { ...result, fileName: file.name }; // ← bug corregido
    renderPreview(result.quotes, result.reportTotal);
    rememberFocus();
    $('previewBg').hidden = false;
    $('previewBg').classList.add('open');
    $('previewCancel').focus();
    setImportStatus(`${result.quotes.length} pedido(s) detectado(s)`, true);
    toast(`Se encontraron ${result.quotes.length} pedidos.`, 'ok');
  } catch (error) {
    console.error('Error de importación:', error);
    pendingImport = null;
    setImportStatus('No se pudo leer el archivo', false, true);
    toast(`No se pudo leer el archivo: ${error?.message || 'Error desconocido'}`, 'err');
  }
}

/* =========================================================
   MODAL CONFIRMACIÓN
========================================================= */
function openModal(title, body, action) {
  modalAction = action;
  $('modalTitle').textContent = title;
  $('modalBody').textContent = body;
  rememberFocus();
  $('modalBg').hidden = false;
  $('modalBg').classList.add('open');
  $('modalCancel').focus();
}
function closeModal() {
  $('modalBg').classList.remove('open');
  $('modalBg').hidden = true;
  modalAction = null;
  restoreFocus();
}

/* =========================================================
   PREVIEW FACTURA
========================================================= */
function openInvoicePreview(quote) {
  if (!quote) { toast('No hay pedido seleccionado.', 'err'); return; }
  $('invoicePreviewTitle').textContent = `Pedido ${quote.numero} · ${quote.cliente || 'Sin cliente'}`;
  $('invoicePreviewFrame').innerHTML = invoice(quote);
  rememberFocus();
  $('invoicePreviewBg').hidden = false;
  $('invoicePreviewBg').classList.add('open');
  $('invoicePreviewClose').focus();
}
function closeInvoicePreview() {
  $('invoicePreviewBg').classList.remove('open');
  $('invoicePreviewBg').hidden = true;
  restoreFocus();
}

/* =========================================================
   PREVIEW VENDEDOR
========================================================= */
function sellerList() {
  if (sellerFilterValue === 'todo') return [...filtered];
  return state.quotes.filter((q) => q.vendedor === sellerFilterValue);
}
function renderSellerPreview() {
  const list = sellerList();
  if (!list.length) {
    $('sellerPreviewTitle').textContent = 'Sin pedidos';
    $('sellerPreviewPosition').textContent = '0 de 0';
    $('sellerPreviewFrame').innerHTML = `
      <div class="empty small-empty">
        <h3>No hay pedidos para mostrar</h3>
        <p>Selecciona un vendedor con pedidos registrados.</p>
      </div>`;
    $('sellerPreviewPrev').disabled = true;
    $('sellerPreviewNext').disabled = true;
    return;
  }
  sellerPreviewIndex = Math.max(0, Math.min(list.length - 1, sellerPreviewIndex));
  const quote = list[sellerPreviewIndex];
  const title = sellerFilterValue === 'todo' ? 'Todos los vendedores' : sellerFilterValue;
  $('sellerPreviewTitle').textContent = `${title} · ${quote.numero}`;
  $('sellerPreviewPosition').textContent = `${sellerPreviewIndex + 1} de ${list.length}`;
  $('sellerPreviewFrame').innerHTML = invoice(quote);
  $('sellerPreviewPrev').disabled = sellerPreviewIndex <= 0;
  $('sellerPreviewNext').disabled = sellerPreviewIndex >= list.length - 1;
}
function openSellerPreview() {
  sellerPreviewIndex = 0;
  renderSellerPreview();
  rememberFocus();
  $('sellerPreviewBg').hidden = false;
  $('sellerPreviewBg').classList.add('open');
  $('sellerPreviewClose').focus();
}
function closeSellerPreview() {
  $('sellerPreviewBg').classList.remove('open');
  $('sellerPreviewBg').hidden = true;
  restoreFocus();
}

/* =========================================================
   IMPRESIÓN
========================================================= */
function printHtml(quotes, title = 'EMA · Pedidos') {
  if (!quotes || !quotes.length) { toast('No hay pedidos para imprimir.', 'err'); return; }
  const documentHtml = `<!doctype html>
<html lang="es-GT">
<head>
<meta charset="utf-8">
<title>${esc(title)}</title>
<style>
  @page { size: auto; margin: 0.12in; }
  * { box-sizing: border-box; }
  html, body { width: 100%; margin: 0; padding: 0; background: #fff; color: #111; font-family: Arial, Helvetica, sans-serif; }
  .page { width: 100%; min-height: 0; margin: 0 auto; padding: 0; page-break-after: always; break-after: page; }
  .page:last-child { page-break-after: auto; break-after: auto; }
  .invoice { position: relative; isolation: isolate; width: 100%; height: auto; min-height: 0; margin: 0 auto; border: 1px solid #111; background: #fff; padding: 0.14in; }
  .invoice::before { content: ""; position: absolute; inset: 4px; z-index: -1; border: 1px solid #d7d7d7; pointer-events: none; }
  .inv-head { text-align: center; border-bottom: 2px solid #111; padding: 0.03in 0.03in 0.09in; }
  .company { font-size: 15px; font-weight: 900; letter-spacing: .07em; }
  .address { margin-top: 3px; font-size: 8px; }
  .title { margin-top: 4px; font-size: 9px; font-weight: 900; letter-spacing: .18em; }
  .invoice table { width: 100%; border-collapse: collapse; }
  .meta { margin-top: 8px; }
  .meta th, .meta td { border: 1px solid #444; padding: 5px; font-size: 7.5px; vertical-align: top; }
  .meta th { background: #fff; text-align: left; font-weight: 900; white-space: nowrap; }
  .items { margin-top: 8px; }
  .items th, .items td { padding: 5px; font-size: 7.5px; vertical-align: top; }
  .items thead tr { border-top: 2px solid #111; border-bottom: 2px solid #111; }
  .items tbody tr { border-bottom: 1px solid #777; }
  .items th { background: #fff; font-weight: 900; }
  .items td { border-left: 1px solid #555; border-right: 1px solid #555; word-break: break-word; }
  .items th.num, .items td.num { text-align: right; white-space: nowrap; }
  .cod { display: block; margin-top: 2px; color: #555; font-size: 6.5px; }
  .total { margin-top: 5px; }
  .total td { padding: 6px; border-top: 2px solid #111; border-bottom: 2px solid #111; font-weight: 900; }
  .total .label { width: 72%; background: #fff; color: #111; text-align: right; }
  .total .value { background: #fff; color: #111; text-align: right; white-space: nowrap; }
  .inv-footer { margin-top: 8px; text-align: center; color: #222; font-size: 8px; font-style: italic; }
  .inv-cond { margin-top: 5px; padding-top: 4px; border-top: 1px dashed #777; text-align: center; color: #555; font-size: 6.5px; }
</style>
</head>
<body>
  ${quotes.map((q) => `<div class="page">${invoice(q)}</div>`).join('')}
</body>
</html>`;

  const printWindow = window.open('', '_blank', 'width=900,height=1000');
  if (!printWindow) {
    toast('El navegador bloqueó la ventana de impresión. Permite ventanas emergentes para EMA.', 'err');
    return;
  }
  printWindow.document.open();
  printWindow.document.write(documentHtml);
  printWindow.document.close();

  const triggerPrint = () => {
    try { printWindow.focus(); } catch (_) {}
    try { printWindow.print(); } catch (_) {}
  };
  printWindow.onload = triggerPrint;
  setTimeout(triggerPrint, 400); // fallback por si onload no dispara
  printWindow.onafterprint = () => { try { printWindow.close(); } catch (_) {} };
}

/* =========================================================
   WORD / PDF / DESCARGAS
========================================================= */
function exportWord(quote) {
  if (!quote) throw new Error('No hay pedido seleccionado.');
  const html = `<!doctype html>
<html lang="es-GT">
<head><meta charset="utf-8"><title>Pedido ${esc(quote.numero)}</title></head>
<body>${invoice(quote)}</body>
</html>`;
  downloadBlob(new Blob([html], { type: 'application/msword' }), `Pedido_${quote.numero}.doc`);
  toast('Word generado correctamente.', 'ok');
}
function exportPdf(quote) {
  if (!window.jspdf || !window.jspdf.jsPDF) throw new Error('La librería PDF no está disponible.');
  if (!quote) throw new Error('No hay pedido seleccionado.');
  const { jsPDF } = window.jspdf;
  const width = 396, height = 612, margin = 24;
  const contentWidth = width - margin * 2;
  const doc = new jsPDF({ unit: 'pt', format: [width, height], compress: true });
  let y = 28;

  function drawHeader(continuation = false) {
    doc.setTextColor(0, 0, 0);
    doc.setDrawColor(20, 20, 20);
    doc.setLineWidth(1);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(13);
    doc.text('MAYOREO ELECTRÓNICO, S.A.', width / 2, y, { align: 'center' });
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.text(COMPANY_ADDRESS, width / 2, y + 12, { align: 'center' });
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9);
    doc.text(
      continuation ? `PEDIDO ${quote.numero} · CONTINUACIÓN` : 'PEDIDO',
      width / 2, y + 25, { align: 'center' }
    );
    doc.line(margin, y + 32, width - margin, y + 32);
    y += 46;
  }
  drawHeader();

  const metadata = [
    ['N. DE COTIZACIÓN', quote.numero],
    ['FECHA', quote.fecha || '—'],
    ['CLIENTE', quote.cliente || '—'],
    ['DIRECCIÓN', quote.direccion || '—'],
    ['VENDEDOR', quote.vendedor || '—']
  ];
  for (const [label, value] of metadata) {
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7.5);
    doc.text(label, margin, y);
    doc.setFont('helvetica', 'normal');
    doc.text(String(value), margin + 94, y);
    doc.line(margin, y + 4, width - margin, y + 4);
    y += 18;
  }
  y += 9;

  function drawColumnsHeader() {
    doc.setFillColor(224, 224, 224);
    doc.setTextColor(20, 20, 20);
    doc.rect(margin, y, contentWidth, 22, 'F');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7.3);
    doc.text('DESCRIPCIÓN', margin + 6, y + 14);
    doc.text('CANT.', 254, y + 14, { align: 'right' });
    doc.text('P. UNIT.', 315, y + 14, { align: 'right' });
    doc.text('TOTAL', 368, y + 14, { align: 'right' });
    y += 29;
  }
  drawColumnsHeader();

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.4);
  for (const item of quote.items) {
    const description = item.descripcion || '—';
    const lines = doc.splitTextToSize(description, 208);
    const rowHeight = Math.max(22, lines.length * 9 + 8);
    if (y + rowHeight > 545) {
      doc.addPage([width, height]);
      y = 28;
      drawHeader(true);
      drawColumnsHeader();
    }
    doc.setFont('helvetica', 'normal');
    doc.text(lines, margin + 6, y + 10);
    doc.text(Number(item.cantidad || 0).toLocaleString('es-GT', { maximumFractionDigits: 2 }), 254, y + 10, { align: 'right' });
    doc.text(money(item.precio), 315, y + 10, { align: 'right' });
    doc.text(money(item.total), 368, y + 10, { align: 'right' });
    doc.setDrawColor(115, 115, 115);
    doc.line(margin, y + rowHeight, width - margin, y + rowHeight);
    y += rowHeight;
  }

  if (y > 545) { doc.addPage([width, height]); y = 32; }
  doc.setFillColor(17, 17, 17);
  doc.setTextColor(255, 255, 255);
  doc.rect(margin, y + 8, contentWidth, 27, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.text('TOTAL DEL PEDIDO', 300, y + 25, { align: 'right' });
  doc.text(money(quote.monto), 370, y + 25, { align: 'right' });
  doc.setTextColor(0, 0, 0);
  doc.setFont('helvetica', 'italic');
  doc.setFontSize(8);
  doc.text('Gracias por su preferencia.', width / 2, 570, { align: 'center' });
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7);
  doc.text('Precios en Quetzales. Documento generado por Sistema EMA.', width / 2, 585, { align: 'center' });
  doc.save(`Pedido_${quote.numero}.pdf`);
  toast('PDF generado correctamente.', 'ok');
}
function downloadBlob(blob, filename) {
  const link = document.createElement('a');
  const url = URL.createObjectURL(blob);
  link.href = url;
  link.download = filename;
  link.style.display = 'none';
  document.body.appendChild(link);
  link.click();
  setTimeout(() => { URL.revokeObjectURL(url); link.remove(); }, 1000);
}

/* =========================================================
   RESPALDO
========================================================= */
function exportBackup() {
  const payload = {
    version: '12.4',
    createdAt: new Date().toISOString(),
    state: JSON.parse(JSON.stringify(state))
  };
  downloadBlob(
    new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json;charset=utf-8' }),
    'EMA-respaldo.json'
  );
  toast('Respaldo creado correctamente.', 'ok');
}

/* =========================================================
   ACCIÓN SEGURA
========================================================= */
function actionSafe(callback, label) {
  try {
    const result = callback();
    if (result && typeof result.catch === 'function') {
      result.catch((error) => {
        console.error(error);
        toast(`${label}: ${error?.message || 'Error desconocido'}`, 'err');
      });
    }
  } catch (error) {
    console.error(error);
    toast(`${label}: ${error?.message || 'Error desconocido'}`, 'err');
  }
}

/* =========================================================
   EVENTOS
========================================================= */
function bind() {
  loadState();
  populateSellers();
  renderHistory();
  renderImportHistory();
  renderQuote();
  setTab('pedidos');

  /* ----- ARCHIVOS ----- */
  const openFilePicker = () => {
    const input = $('fileInput');
    if (!input) { toast('No se encontró el selector de archivos.', 'err'); return; }
    input.value = '';
    input.click();
  };
  $('btnOpenImport').onclick = openFilePicker;
  $('btnImportPrimary').onclick = openFilePicker;
  $('btnImportDrop').onclick = openFilePicker;
  $('btnImportEmpty').onclick = openFilePicker;
  $('btnClearBase').onclick = () => openModal(
    'Vaciar base actual',
    'Se eliminarán los pedidos actualmente cargados, pero el historial de archivos importados se conservará.',
    () => {
      state.quotes = [];
      state.meta = { lastFile: '', lastImportedAt: null, reportTotal: 0 };
      saveState();
      selected = 0;
      sellerFilterValue = 'todo';
      populateSellers();
      renderHistory();
      renderQuote();
      toast('Base actual vaciada. El historial se conserva.', 'ok');
    }
  );
  $('dropZone').onclick = openFilePicker;
  $('dropZone').addEventListener('keydown', (event) => {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      openFilePicker();
    }
  });
  $('fileInput').addEventListener('change', (event) => {
    const file = event.target.files?.[0];
    event.target.value = '';
    handleFile(file);
  });
  const dropZone = $('dropZone');
  dropZone.addEventListener('dragover', (event) => {
    event.preventDefault();
    dropZone.classList.add('drag');
  });
  dropZone.addEventListener('dragleave', () => dropZone.classList.remove('drag'));
  dropZone.addEventListener('drop', (event) => {
    event.preventDefault();
    dropZone.classList.remove('drag');
    const file = event.dataTransfer?.files?.[0];
    handleFile(file);
  });

  /* ----- TABS ----- */
  document.querySelectorAll('.tab').forEach((button) => {
    button.onclick = () => setTab(button.dataset.tab);
  });

  /* ----- NAVEGACIÓN ----- */
  $('btnFirst').onclick = () => goToQuote(0);
  $('btnPrev').onclick = () => goToQuote(selected - 1);
  $('btnNext').onclick = () => goToQuote(selected + 1);
  $('btnLast').onclick = () => goToQuote(filtered.length - 1);
  $('quoteJump').onchange = (event) => {
    const value = event.target.value;
    if (value === '') return; // guardia: opción "Sin pedidos"
    goToQuote(Number(value) || 0);
  };

  /* ----- VENDEDORES ----- */
  function changeSeller(value) {
    sellerFilterValue = value || 'todo';
    selected = 0;
    populateSellers();
    renderHistory();
    renderQuote();
  }
  $('sellerFilter').onchange = (event) => changeSeller(event.target.value);
  $('quoteSellerFilter').onchange = (event) => changeSeller(event.target.value);

  /* ----- FILTROS ----- */
  ['search', 'sort', 'dateFilter'].forEach((id) => {
    $(id).addEventListener('input', () => { selected = 0; renderHistory(); renderQuote(); });
    $(id).addEventListener('change', () => { selected = 0; renderHistory(); renderQuote(); });
  });
  $('btnReset').onclick = () => {
    // el form resetea los campos; setTimeout espera a que el navegador aplique el reset
    setTimeout(() => {
      $('search').value = '';
      $('sort').value = 'fecha_desc';
      $('dateFilter').value = 'todo';
      sellerFilterValue = 'todo';
      selected = 0;
      populateSellers();
      renderHistory();
      renderQuote();
    }, 0);
  };

  /* ----- IMPRESIÓN ----- */
  $('btnPrint').onclick = () => actionSafe(() => {
    const quote = currentQuote();
    if (!quote) throw new Error('No hay pedido seleccionado.');
    printHtml([quote], `Pedido ${quote.numero}`);
  }, 'No se pudo imprimir');
  $('btnPrintAll').onclick = () => actionSafe(() => {
    applyFilters();
    if (!filtered.length) throw new Error('No hay pedidos para imprimir.');
    printHtml(filtered, sellerFilterValue === 'todo' ? 'Pedidos EMA' : `Pedidos de ${sellerFilterValue}`);
  }, 'No se pudo imprimir');
  $('btnHistoryPrint').onclick = () => actionSafe(() => {
    applyFilters();
    if (!filtered.length) throw new Error('No hay resultados.');
    printHtml(filtered, 'Resultados EMA');
  }, 'No se pudo imprimir');

  /* ----- PDF / WORD ----- */
  $('btnPdf').onclick = () => actionSafe(() => {
    const quote = currentQuote();
    if (!quote) throw new Error('No hay pedido seleccionado.');
    exportPdf(quote);
  }, 'No se pudo generar el PDF');
  $('btnWord').onclick = () => actionSafe(() => {
    const quote = currentQuote();
    if (!quote) throw new Error('No hay pedido seleccionado.');
    exportWord(quote);
  }, 'No se pudo generar Word');

  /* ----- PREVIEWS ----- */
  $('btnPreviewCurrent').onclick = () => openInvoicePreview(currentQuote());
  $('btnPreviewSeller').onclick = () => openSellerPreview();
  $('invoicePreviewX').onclick = closeInvoicePreview;
  $('invoicePreviewClose').onclick = closeInvoicePreview;
  $('invoicePreviewPrint').onclick = () => actionSafe(() => {
    const quote = currentQuote();
    if (!quote) throw new Error('No hay pedido seleccionado.');
    printHtml([quote], `Pedido ${quote.numero}`);
  }, 'No se pudo imprimir');
  $('sellerPreviewX').onclick = closeSellerPreview;
  $('sellerPreviewClose').onclick = closeSellerPreview;
  $('sellerPreviewPrev').onclick = () => { sellerPreviewIndex--; renderSellerPreview(); };
  $('sellerPreviewNext').onclick = () => { sellerPreviewIndex++; renderSellerPreview(); };
  $('sellerPreviewPrint').onclick = () => actionSafe(() => {
    const list = sellerList();
    if (!list.length) throw new Error('No hay pedidos para este vendedor.');
    printHtml([list[sellerPreviewIndex]], 'Vista del vendedor');
  }, 'No se pudo imprimir');

  /* ----- MODAL CONFIRMACIÓN ----- */
  $('modalX').onclick = closeModal;
  $('modalCancel').onclick = closeModal;
  $('modalOk').onclick = () => {
    const action = modalAction;
    closeModal();
    if (typeof action === 'function') action();
  };
  $('modalBg').onclick = (event) => {
    if (event.target === event.currentTarget) closeModal();
  };

  /* ----- PREVIEW IMPORTACIÓN ----- */
  $('previewX').onclick = closeImportPreview;
  $('previewCancel').onclick = closeImportPreview;
  const commitPendingImport = (mode) => {
    if (!pendingImport) { toast('No hay una importación pendiente.', 'err'); return; }
    const data = pendingImport;
    const count = data.quotes.length;
    if (mode === 'replace') {
      replaceImported(data.quotes, data.reportTotal, data.fileName);
      toast(`${count} pedidos cargados. La base anterior fue reemplazada.`, 'ok');
    } else {
      mergeImported(data.quotes, data.reportTotal, data.fileName);
      toast(`${count} pedidos agregados a la base.`, 'ok');
    }
    pendingImport = null;
    closeImportPreview();
    setTab('pedidos');
  };
  $('previewAppend').onclick = () => commitPendingImport('append');
  $('previewReplace').onclick = () => commitPendingImport('replace');
  $('previewBg').onclick = (event) => {
    if (event.target === event.currentTarget) closeImportPreview();
  };

  /* ----- HISTORIAL ----- */
  $('historyBody').onclick = (event) => {
    const button = event.target.closest('button');
    if (!button) return;
    const id = button.dataset.id;
    if (button.dataset.act === 'view') {
      applyFilters();
      const index = filtered.findIndex((q) => q.id === id);
      if (index >= 0) { selected = index; setTab('pedidos'); renderQuote(); }
      return;
    }
    if (button.dataset.act === 'del') {
      openModal(
        'Eliminar pedido',
        '¿Deseas eliminar este pedido del historial? Esta acción no se puede deshacer.',
        () => {
          state.quotes = state.quotes.filter((q) => q.id !== id);
          saveState();
          selected = 0;
          renderHistory();
          renderQuote();
          toast('Pedido eliminado.', 'ok');
        }
      );
    }
  };

  $('importHistoryBody').onclick = (event) => {
    const button = event.target.closest('button');
    if (!button || button.dataset.importAct !== 'view') return;
    openImportHistoryPreview(button.dataset.id);
  };

  $('importHistoryPreviewX').onclick = closeImportHistoryPreview;
  $('importHistoryPreviewClose').onclick = closeImportHistoryPreview;
  $('importHistoryPreviewBg').onclick = (event) => {
    if (event.target === event.currentTarget) closeImportHistoryPreview();
  };

  /* ----- VACIAR HISTORIAL ----- */
  $('btnClear').onclick = () => openModal(
    'Vaciar historial de pedidos',
    'Se eliminarán los pedidos guardados en la base actual. El historial de archivos importados se conservará.',
    () => {
      state.quotes = [];
      state.meta = { lastFile: '', lastImportedAt: null, reportTotal: 0 };
      saveState();
      selected = 0;
      sellerFilterValue = 'todo';
      populateSellers();
      renderHistory();
      renderImportHistory();
      renderQuote();
      toast('Base de pedidos vaciada. El historial de archivos se conserva.', 'ok');
    }
  );

  /* ----- RESPALDO / RESTAURAR ----- */
  $('btnBackup').onclick = () => actionSafe(exportBackup, 'No se pudo crear el respaldo');
  $('btnRestore').onclick = () => $('restoreInput').click();
  $('restoreInput').onchange = async (event) => {
    const file = event.target.files?.[0];
    event.target.value = '';
    if (!file) return;
    try {
      const text = await file.text();
      const data = JSON.parse(text);
      if (!data?.state || !Array.isArray(data.state.quotes)) {
        throw new Error('El archivo no contiene un respaldo EMA válido.');
      }
      state.quotes = data.state.quotes.map(normalizeQuote);
      state.meta = { ...state.meta, ...(data.state.meta || {}) };
      saveState();
      selected = 0;
      sellerFilterValue = 'todo';
      populateSellers();
      renderHistory();
      renderImportHistory();
      renderQuote();
      toast('Respaldo restaurado correctamente.', 'ok');
    } catch (error) {
      toast(`No se pudo restaurar: ${error?.message || 'Error desconocido'}`, 'err');
    }
  };

  /* ----- TECLADO ----- */
  document.addEventListener('keydown', (event) => {
    const tag = (event.target?.tagName || '').toLowerCase();
    if (['input', 'textarea', 'select', 'button'].includes(tag) || event.ctrlKey || event.metaKey || event.altKey) return;
    switch (event.key) {
      case 'ArrowLeft': event.preventDefault(); goToQuote(selected - 1); break;
      case 'ArrowRight': event.preventDefault(); goToQuote(selected + 1); break;
      case 'Home': event.preventDefault(); goToQuote(0); break;
      case 'End': event.preventDefault(); goToQuote(filtered.length - 1); break;
      case 'Escape':
        event.preventDefault();
        closeModal();
        closeInvoicePreview();
        closeSellerPreview();
        closeImportPreview(); // ← ahora también cierra el modal de importación
        break;
    }
  });

  /* ----- CLICK FUERA DE PREVIEWS ----- */
  $('invoicePreviewBg').onclick = (event) => {
    if (event.target === event.currentTarget) closeInvoicePreview();
  };
  $('sellerPreviewBg').onclick = (event) => {
    if (event.target === event.currentTarget) closeSellerPreview();
  };

  /* ----- ERRORES GLOBALES ----- */
  window.addEventListener('error', (event) => {
    const message = event?.message || '';
    if (!message || /ResizeObserver/i.test(message)) return;
    console.error('Error EMA:', event);
    toast(`Error de la aplicación: ${message}`, 'err');
  });
  window.addEventListener('unhandledrejection', (event) => {
    if (!event.reason) return;
    console.error('Promesa rechazada:', event.reason);
    toast(`Error: ${event.reason?.message || String(event.reason)}`, 'err');
  });

  setSystemStatus('Listo para trabajar', 'success');
}

/* =========================================================
   ARRANQUE
========================================================= */
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', bind, { once: true });
} else {
  bind();
}